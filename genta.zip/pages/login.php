<?php
header("location: ./auth");