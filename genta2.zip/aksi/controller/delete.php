<?php
include '../ctrl/controller.php';

$name = $_POST['name'];

$embo->remove($name);