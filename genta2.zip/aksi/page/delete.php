<?php
include '../ctrl/controller.php';

$name = $_POST['name'];
$embo->removePage($name);