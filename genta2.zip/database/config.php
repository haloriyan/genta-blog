<?php
global $dbHost,$dbUsername,$dbPassword,$dbName,$baseUrl;

// $dbHost 	= "spectre.beon.co.id";
// $dbUsername = "imajingg_genta";
// $dbPassword = "inikatasandi";
// $dbName 	= "imajingg_genta";

$dbHost 	= "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName 	= "genta";
$baseUrl 	= "http://localhost/genta";

?>