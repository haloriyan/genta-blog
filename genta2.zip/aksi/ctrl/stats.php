<?php
include 'controller.php';

class stats extends EMBO {
	public function visitor() {
		//
	}
}

$stats = new stats();

?>