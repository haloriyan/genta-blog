<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1">
	<title>Agendakota Hashtag</title>
	<link href="aset/fw/build/fw.css" rel="stylesheet">
	<link href="aset/fw/build/fontawesome-all.min.css" rel="stylesheet">
	<link href="aset/css/style.css" rel="stylesheet">
	<link href="aset/img/favicon.ico" rel="icon">
</head>
<body>

<div class="ricomplete">
	<input type="text" id="myInput">
</div>

<script src="aset/js/embo.js"></script>
<script>
	function refresh(str) {
		let p = str.split(',')
		let tot = p.length
		let y = p.splice(0, tot - 1)
		return y
	}

	refresh('love,song,music')
</script>

</body>
</html>